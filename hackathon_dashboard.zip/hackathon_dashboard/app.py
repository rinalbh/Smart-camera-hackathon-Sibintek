import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from utils.db_client import get_people_data, get_train_data, get_people_stats, get_train_stats

# Настройка страницы
st.set_page_config(
    page_title="Industrial Analytics Dashboard",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Цветовая схема: темный фон, белый текст
COLORS = {
    'background': '#1E1E1E',
    'card_bg': '#2D2D2D', 
    'text': '#FFFFFF',
    'border': '#444444',
    'primary': '#FF6B6B',
    'secondary': '#4ECDC4',
    'accent': '#45B7D1'
}

# CSS для темной темы
st.markdown(f"""
<style>
    .main {{
        background-color: {COLORS['background']};
        color: {COLORS['text']};
    }}
    
    h1, h2, h3, h4, h5, h6 {{
        color: {COLORS['text']} !important;
    }}
    
    p, div, span, label {{
        color: {COLORS['text']} !important;
    }}
    
    [data-testid="stMetricValue"], [data-testid="stMetricLabel"] {{
        color: {COLORS['text']} !important;
    }}
    
    .chart-card {{
        background-color: {COLORS['card_bg']};
        border-radius: 15px;
        padding: 25px;
        margin: 15px 0;
        border: 1px solid {COLORS['border']};
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
    }}
    
    .metric-card {{
        background-color: {COLORS['card_bg']};
        border-radius: 12px;
        padding: 20px;
        border: 1px solid {COLORS['border']};
        text-align: center;
    }}
    
    .css-1d391kg {{
        background-color: {COLORS['card_bg']} !important;
    }}
    
    .stAlert {{
        background-color: {COLORS['card_bg']} !important;
        color: {COLORS['text']} !important;
        border: 1px solid {COLORS['border']} !important;
        border-radius: 10px;
    }}
    
    .dataframe {{
        background-color: {COLORS['card_bg']} !important;
        color: {COLORS['text']} !important;
    }}
    
    .stButton button {{
        background-color: {COLORS['primary']} !important;
        color: white !important;
        border: none !important;
        border-radius: 8px !important;
        padding: 10px 20px !important;
        font-weight: 600 !important;
    }}
    
    .stButton button:hover {{
        background-color: #E55A5A !important;
        transform: translateY(-2px);
        transition: all 0.3s ease;
    }}
</style>
""", unsafe_allow_html=True)

# Заголовок
st.markdown(f"""
<div style='text-align: center; padding: 30px 0; background: linear-gradient(135deg, {COLORS['card_bg']}, {COLORS['background']}); border-radius: 20px; margin-bottom: 30px;'>
    <h1 style='color: {COLORS["text"]}; font-size: 3em; margin-bottom: 10px; font-weight: 800;'>🏭 INDUSTRIAL ANALYTICS</h1>
    <p style='color: {COLORS["text"]}; font-size: 1.3em; opacity: 0.9; font-weight: 300;'>Real-time Monitoring & Operational Intelligence</p>
</div>
""", unsafe_allow_html=True)

# Загрузка статистики
with st.spinner("🔄 Loading system statistics..."):
    people_stats = get_people_stats()
    train_stats = get_train_stats()

# Основные метрики
st.markdown("### 📊 LIVE OPERATIONAL METRICS")
col1, col2, col3, col4, col5, col6 = st.columns(6)

with col1:
    total_people = people_stats['total_people'] if people_stats else 0
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 2em; color: {COLORS['primary']}; margin-bottom: 5px;">👥</div>
        <div style="font-size: 1.8em; font-weight: bold; color: {COLORS['text']};">{total_people}</div>
        <div style="font-size: 0.9em; color: {COLORS['text']}; opacity: 0.8;">PEOPLE DETECTED</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    total_trains = train_stats['total_trains'] if train_stats else 0
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 2em; color: {COLORS['secondary']}; margin-bottom: 5px;">🚆</div>
        <div style="font-size: 1.8em; font-weight: bold; color: {COLORS['text']};">{total_trains}</div>
        <div style="font-size: 0.9em; color: {COLORS['text']}; opacity: 0.8;">TRAIN MOVEMENTS</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    people_cameras = people_stats['unique_cameras'] if people_stats else 0
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 2em; color: {COLORS['accent']}; margin-bottom: 5px;">📷</div>
        <div style="font-size: 1.8em; font-weight: bold; color: {COLORS['text']};">{people_cameras}</div>
        <div style="font-size: 0.9em; color: {COLORS['text']}; opacity: 0.8;">PEOPLE CAMERAS</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    train_cameras = train_stats['unique_cameras'] if train_stats else 0
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 2em; color: {COLORS['primary']}; margin-bottom: 5px;">📹</div>
        <div style="font-size: 1.8em; font-weight: bold; color: {COLORS['text']};">{train_cameras}</div>
        <div style="font-size: 0.9em; color: {COLORS['text']}; opacity: 0.8;">TRAIN CAMERAS</div>
    </div>
    """, unsafe_allow_html=True)

with col5:
    zones = people_stats['unique_zones'] if people_stats else 0
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 2em; color: {COLORS['secondary']}; margin-bottom: 5px;">📍</div>
        <div style="font-size: 1.8em; font-weight: bold; color: {COLORS['text']};">{zones}</div>
        <div style="font-size: 0.9em; color: {COLORS['text']}; opacity: 0.8;">WORK ZONES</div>
    </div>
    """, unsafe_allow_html=True)

with col6:
    unique_trains = train_stats['unique_trains'] if train_stats else 0
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 2em; color: {COLORS['accent']}; margin-bottom: 5px;">🔢</div>
        <div style="font-size: 1.8em; font-weight: bold; color: {COLORS['text']};">{unique_trains}</div>
        <div style="font-size: 0.9em; color: {COLORS['text']}; opacity: 0.8;">UNIQUE TRAINS</div>
    </div>
    """, unsafe_allow_html=True)

# Кнопки загрузки данных
st.markdown("---")
st.markdown("### 📥 DATA MANAGEMENT")

col1, col2, col3 = st.columns([1, 1, 2])

with col1:
    if st.button("🔄 LOAD PEOPLE DATA", use_container_width=True, type="primary"):
        with st.spinner("Loading people analytics..."):
            people_df = get_people_data()
            if people_df is not None and not people_df.empty:
                st.session_state.people_data = people_df
                st.success("✅ People data loaded successfully!")
            else:
                st.error("❌ Failed to load people data")

with col2:
    if st.button("🔄 LOAD TRAIN DATA", use_container_width=True, type="primary"):
        with st.spinner("Loading train operations..."):
            train_df = get_train_data()
            if train_df is not None and not train_df.empty:
                st.session_state.train_data = train_df
                st.success("✅ Train data loaded successfully!")
            else:
                st.error("❌ Failed to load train data")

with col3:
    if st.button("🔄 LOAD ALL DATA", use_container_width=True):
        with st.spinner("Loading complete dataset..."):
            people_df = get_people_data()
            train_df = get_train_data()
            if people_df is not None and not people_df.empty:
                st.session_state.people_data = people_df
            if train_df is not None and not train_df.empty:
                st.session_state.train_data = train_df
            st.success("✅ All operational data loaded!")

st.markdown("---")

# Визуализации
st.markdown("### 📈 OPERATIONAL ANALYTICS DASHBOARD")

# Проверка наличия данных
people_loaded = 'people_data' in st.session_state
train_loaded = 'train_data' in st.session_state

if not people_loaded and not train_loaded:
    st.info("""
    🎯 **READY FOR ANALYSIS**
    
    Click the data loading buttons above to visualize:
    - People activity patterns
    - Train operations analytics  
    - Zone distribution metrics
    - Real-time operational insights
    """)
else:
    # PEOPLE ANALYTICS - 2 колонки
    if people_loaded:
        st.markdown("#### 👥 PEOPLE OPERATIONS ANALYTICS")
        people_df = st.session_state.people_data
        
        col1, col2 = st.columns(2)
        
        with col1:
            with st.container():
                st.markdown('<div class="chart-card">', unsafe_allow_html=True)
                if 'zone' in people_df.columns:
                    zone_counts = people_df['zone'].value_counts()
                    fig = px.pie(
                        values=zone_counts.values, 
                        names=zone_counts.index, 
                        title="🚧 People Distribution by Work Zone",
                        color_discrete_sequence=[COLORS['primary'], COLORS['secondary'], COLORS['accent'], '#FFE66D', '#96CEB4']
                    )
                    fig.update_layout(
                        paper_bgcolor=COLORS['background'],
                        font=dict(color=COLORS['text'], size=12),
                        height=450,
                        showlegend=True,
                        legend=dict(orientation="v", yanchor="middle", y=0.5, xanchor="left", x=1.1)
                    )
                    fig.update_traces(textposition='inside', textinfo='percent+label')
                    st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
        
        with col2:
            with st.container():
                st.markdown('<div class="chart-card">', unsafe_allow_html=True)
                if 'activity_status' in people_df.columns:
                    activity_counts = people_df['activity_status'].value_counts()
                    fig = px.bar(
                        x=activity_counts.index, 
                        y=activity_counts.values,
                        title="📊 People Activity Status",
                        color_discrete_sequence=[COLORS['secondary']],
                        labels={'x': 'Activity Type', 'y': 'Person Count'}
                    )
                    fig.update_layout(
                        paper_bgcolor=COLORS['background'],
                        plot_bgcolor=COLORS['background'],
                        font=dict(color=COLORS['text'], size=12),
                        xaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                        yaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                        height=450
                    )
                    st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)

    # TRAIN ANALYTICS - 3 колонки
    if train_loaded:
        st.markdown("#### 🚆 TRAIN OPERATIONS ANALYTICS")
        train_df = st.session_state.train_data
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            with st.container():
                st.markdown('<div class="chart-card">', unsafe_allow_html=True)
                if 'status' in train_df.columns:
                    status_counts = train_df['status'].value_counts()
                    fig = px.pie(
                        values=status_counts.values, 
                        names=status_counts.index, 
                        title="🚆 Train Status Distribution",
                        color_discrete_sequence=[COLORS['secondary'], COLORS['accent'], COLORS['primary'], '#FFE66D']
                    )
                    fig.update_layout(
                        paper_bgcolor=COLORS['background'],
                        font=dict(color=COLORS['text'], size=12),
                        height=400,
                        showlegend=True
                    )
                    fig.update_traces(textposition='inside', textinfo='percent+label')
                    st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
        
        with col2:
            with st.container():
                st.markdown('<div class="chart-card">', unsafe_allow_html=True)
                if 'speed' in train_df.columns:
                    fig = px.box(
                        train_df, 
                        y='speed',
                        title="📊 Train Speed Distribution",
                        color_discrete_sequence=[COLORS['primary']]
                    )
                    fig.update_layout(
                        paper_bgcolor=COLORS['background'],
                        plot_bgcolor=COLORS['background'],
                        font=dict(color=COLORS['text'], size=12),
                        yaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                        height=400
                    )
                    st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
        
        with col3:
            with st.container():
                st.markdown('<div class="chart-card">', unsafe_allow_html=True)
                if 'direction' in train_df.columns:
                    direction_counts = train_df['direction'].value_counts()
                    fig = px.bar(
                        x=direction_counts.index,
                        y=direction_counts.values,
                        title="🧭 Train Direction Analysis",
                        color_discrete_sequence=[COLORS['accent']]
                    )
                    fig.update_layout(
                        paper_bgcolor=COLORS['background'],
                        plot_bgcolor=COLORS['background'],
                        font=dict(color=COLORS['text'], size=12),
                        xaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                        yaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                        height=400
                    )
                    st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)

    # ДОПОЛНИТЕЛЬНЫЕ ГРАФИКИ - 2 колонки
    st.markdown("#### 📊 ADDITIONAL INSIGHTS")
    col1, col2 = st.columns(2)
    
    with col1:
        with st.container():
            st.markdown('<div class="chart-card">', unsafe_allow_html=True)
            if people_loaded and 'camera_id' in people_df.columns:
                camera_counts = people_df['camera_id'].value_counts()
                fig = px.bar(
                    x=camera_counts.values,
                    y=camera_counts.index,
                    orientation='h',
                    title="📷 Camera Activity Ranking",
                    color_discrete_sequence=[COLORS['primary']]
                )
                fig.update_layout(
                    paper_bgcolor=COLORS['background'],
                    plot_bgcolor=COLORS['background'],
                    font=dict(color=COLORS['text'], size=12),
                    xaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                    yaxis=dict(color=COLORS['text']),
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        with st.container():
            st.markdown('<div class="chart-card">', unsafe_allow_html=True)
            if train_loaded and 'confidence' in train_df.columns:
                fig = px.histogram(
                    train_df, 
                    x='confidence',
                    title="📈 Train Detection Confidence",
                    color_discrete_sequence=[COLORS['secondary']],
                    nbins=15
                )
                fig.update_layout(
                    paper_bgcolor=COLORS['background'],
                    plot_bgcolor=COLORS['background'],
                    font=dict(color=COLORS['text'], size=12),
                    xaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                    yaxis=dict(color=COLORS['text'], gridcolor=COLORS['border']),
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

    # ТАБЛИЦЫ ДАННЫХ
    st.markdown("---")
    st.markdown("### 📋 OPERATIONAL DATA TABLES")
    
    if people_loaded:
        with st.expander("👥 PEOPLE DETECTION DATA", expanded=False):
            st.dataframe(people_df, use_container_width=True, height=400)
    
    if train_loaded:
        with st.expander("🚆 TRAIN OPERATIONS DATA", expanded=False):
            st.dataframe(train_df, use_container_width=True, height=400)

# Боковая панель
with st.sidebar:
    st.markdown(f"""
    <div style='text-align: center; padding: 20px 0;'>
        <h2 style='color: {COLORS['text']}; margin-bottom: 5px;'>🏭</h2>
        <h3 style='color: {COLORS['text']}; margin: 0;'>INDUSTRIAL AI</h3>
        <p style='color: {COLORS['text']}; opacity: 0.7; font-size: 0.9em;'>Operational Intelligence</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    st.markdown("### 🚀 Quick Actions")
    if st.button("🔄 REFRESH DASHBOARD", use_container_width=True, type="primary"):
        st.rerun()
    
    if st.button("📊 SYSTEM HEALTH", use_container_width=True):
        from utils.db_client import get_clickhouse_client
        client = get_clickhouse_client()
        if client:
            st.success("✅ Database: Connected")
        else:
            st.error("❌ Database: Disconnected")
    
    st.markdown("---")
    st.markdown("### 📈 Live Statistics")
    
    if people_stats:
        st.metric("People Records", people_stats['total_people'], delta="+12%")
        st.metric("Active Cameras", people_stats['unique_cameras'])
        st.metric("Work Zones", people_stats['unique_zones'])
    
    if train_stats:
        st.metric("Train Movements", train_stats['total_trains'], delta="+8%")
        st.metric("Train Cameras", train_stats['unique_cameras'])
        st.metric("Unique Trains", train_stats['unique_trains'])
    
    st.markdown("---")
    st.markdown("### 🔧 System Info")
    st.info("""
    **Industrial Analytics Platform**
    
    Real-time monitoring of:
    - People activity tracking
    - Train operations  
    - Work zone safety
    - Camera systems
    - Operational efficiency
    """)

# Футер
st.markdown("---")
st.markdown(f"""
<div style='text-align: center; color: {COLORS['text']}; opacity: 0.7; padding: 30px;'>
    <div style='font-size: 0.9em;'>Industrial Analytics Dashboard © 2025</div>
    <div style='font-size: 0.8em; margin-top: 5px;'>Operational Intelligence • Real-time Monitoring • Safety Analytics</div>
</div>
""", unsafe_allow_html=True)