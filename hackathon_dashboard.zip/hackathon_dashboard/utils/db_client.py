import streamlit as st
from clickhouse_driver import Client
import pandas as pd

def get_clickhouse_client():
    """Создание клиента ClickHouse"""
    try:
        client = Client(
            host=st.secrets.get("CLICKHOUSE_HOST"),
            port=int(st.secrets.get("CLICKHOUSE_PORT", 8443)),
            user=st.secrets.get("CLICKHOUSE_USER"),
            password=st.secrets.get("CLICKHOUSE_PASSWORD"),
            database=st.secrets.get("CLICKHOUSE_DATABASE", "default"),
            secure=True
        )
        return client
    except Exception as e:
        st.error(f"Database connection error: {e}")
        return None

def get_people_data():
    """Получение данных о людях"""
    try:
        client = get_clickhouse_client()
        if not client:
            return None
        
        # Если таблицы нет, создаем демо-данные
        try:
            query = """
            SELECT 
                id, timestamp, camera_id, zone, 
                activity_status, confidence, person_id
            FROM people_detections 
            ORDER BY timestamp DESC 
            LIMIT 1000
            """
            result = client.execute(query)
            
            df = pd.DataFrame(result, columns=[
                'id', 'timestamp', 'camera_id', 'zone', 
                'activity_status', 'confidence', 'person_id'
            ])
            return df
        except Exception:
            # Создаем демо-данные если таблицы нет
            return create_demo_people_data()
            
    except Exception as e:
        st.error(f"Error loading people data: {e}")
        return create_demo_people_data()

def get_train_data():
    """Получение данных о поездах"""
    try:
        client = get_clickhouse_client()
        if not client:
            return None
        
        # Если таблицы нет, создаем демо-данные
        try:
            query = """
            SELECT 
                id, timestamp, camera_id, train_number,
                status, speed, direction, confidence
            FROM train_detections 
            ORDER BY timestamp DESC 
            LIMIT 1000
            """
            result = client.execute(query)
            
            df = pd.DataFrame(result, columns=[
                'id', 'timestamp', 'camera_id', 'train_number',
                'status', 'speed', 'direction', 'confidence'
            ])
            return df
        except Exception:
            # Создаем демо-данные если таблицы нет
            return create_demo_train_data()
            
    except Exception as e:
        st.error(f"Error loading train data: {e}")
        return create_demo_train_data()

def get_people_stats():
    """Статистика по людям"""
    try:
        client = get_clickhouse_client()
        if not client:
            return create_demo_people_stats()
        
        try:
            query = """
            SELECT 
                COUNT(*) as total_people,
                COUNT(DISTINCT camera_id) as unique_cameras,
                COUNT(DISTINCT zone) as unique_zones
            FROM people_detections
            """
            result = client.execute(query)
            
            return {
                'total_people': result[0][0],
                'unique_cameras': result[0][1],
                'unique_zones': result[0][2]
            }
        except Exception:
            return create_demo_people_stats()
            
    except Exception as e:
        return create_demo_people_stats()

def get_train_stats():
    """Статистика по поездам"""
    try:
        client = get_clickhouse_client()
        if not client:
            return create_demo_train_stats()
        
        try:
            query = """
            SELECT 
                COUNT(*) as total_trains,
                COUNT(DISTINCT camera_id) as unique_cameras,
                COUNT(DISTINCT train_number) as unique_trains
            FROM train_detections
            """
            result = client.execute(query)
            
            return {
                'total_trains': result[0][0],
                'unique_cameras': result[0][1],
                'unique_trains': result[0][2]
            }
        except Exception:
            return create_demo_train_stats()
            
    except Exception as e:
        return create_demo_train_stats()

def create_demo_people_data():
    """Создание демо-данных о людях"""
    import random
    from datetime import datetime, timedelta
    
    zones = ['Zone A', 'Zone B', 'Zone C', 'Zone D']
    activities = ['working', 'walking', 'idle', 'meeting']
    cameras = ['CAM-001', 'CAM-002', 'CAM-003', 'CAM-004']
    
    data = []
    for i in range(100):
        timestamp = datetime.now() - timedelta(hours=random.randint(0, 24))
        data.append({
            'id': i + 1,
            'timestamp': timestamp,
            'camera_id': random.choice(cameras),
            'zone': random.choice(zones),
            'activity_status': random.choice(activities),
            'confidence': round(random.uniform(0.7, 0.99), 2),
            'person_id': f"P{random.randint(1000, 9999)}"
        })
    
    return pd.DataFrame(data)

def create_demo_train_data():
    """Создание демо-данных о поездах"""
    import random
    from datetime import datetime, timedelta
    
    statuses = ['arrived', 'departed', 'in_transit', 'maintenance']
    directions = ['north', 'south', 'east', 'west']
    cameras = ['CAM-T-001', 'CAM-T-002', 'CAM-T-003']
    
    data = []
    for i in range(50):
        timestamp = datetime.now() - timedelta(hours=random.randint(0, 24))
        data.append({
            'id': i + 1,
            'timestamp': timestamp,
            'camera_id': random.choice(cameras),
            'train_number': f"TR{random.randint(100, 999)}",
            'status': random.choice(statuses),
            'speed': random.randint(0, 120),
            'direction': random.choice(directions),
            'confidence': round(random.uniform(0.8, 0.99), 2)
        })
    
    return pd.DataFrame(data)

def create_demo_people_stats():
    """Демо-статистика по людям"""
    return {
        'total_people': 847,
        'unique_cameras': 4,
        'unique_zones': 4
    }

def create_demo_train_stats():
    """Демо-статистика по поездам"""
    return {
        'total_trains': 156,
        'unique_cameras': 3,
        'unique_trains': 23
    }